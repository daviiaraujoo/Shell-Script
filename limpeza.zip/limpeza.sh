#!/bin/bash

#serve para limpar a lixeira as quintas-feiras  as 20:05 horas

if [ $(date +%u) -eq 4 ] && [ $(date +%H%M) -eq 2005 ]; then

echo "Limpando a lixeira..."

rm -rf ~/.local/share/Trash/*

if [ $? -eq 0 ]; then
echo "Lixeira limpa com sucesso..."
else 
echo "Ocorreu um erro ao limpar a lixeira..."
fi
else
echo "Hoje não é dia ou horario agendado para limpar a lixeira..."

fi

exit 0

