#!/bin/bash

echo "digite o primeiro numero"
read num1
echo
echo "digite o segundo numero"
read num2
echo
echo "Digite: 1- Somar  2- Subtrair  3- Multiplicação 4- Divisão"
read escolha
echo
if [ $escolha == 1 ]; then
res=$(( num1 + num2 ))
echo "a soma do " $num1 " com " $num2 " é " $res 
elif [ $escolha == 2 ]; then
res2=$(( num1 - num2  ))
echo "a subtração de " $num1 " com " $num2 " é " $res2
elif [ $escolha == 3  ]; then
res3=$(( num1 * num2  ))
echo "a multiplicação de " $num1 " com " $num2 " é " $res3
elif [ $escolha == 4 ]; then
res4=$(( num1 / num2))
echo "a divisão de " $num1 " com " $num2 " é " $res4
fi
